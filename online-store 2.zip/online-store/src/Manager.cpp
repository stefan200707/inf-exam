#include "../include/Manager.h"
#include <iostream>

void Manager::showMenu() {
    std::cout << "\n[MANAGER MENU]\n";
    std::cout << "1) View products\n";
    std::cout << "2) Update order status\n";
    std::cout << "0) Exit\n";
}
