#include <iostream>
#include <memory>
#include <pqxx/pqxx>

#include "StoreService.h"
#include "Admin.h"
#include "Manager.h"
#include "Customer.h"

std::unique_ptr<User> login() {
  int choice;
  std::cout << "Choose role:\n";
  std::cout << "1) Admin\n";
  std::cout << "2) Manager\n";
  std::cout << "3) Customer\n";
  std::cout << "Enter: ";
  std::cin >> choice;

  if (choice == 1) return std::make_unique<Admin>(1, "Admin");
  if (choice == 2) return std::make_unique<Manager>(2, "Manager");
  return std::make_unique<Customer>(3, "Customer");
}

int main() {
  try {
    DatabaseConnection<std::string> db(
    "host=localhost port=5432 dbname=store_exam user=postgres password=stef4587"
);

    StoreService service(db);


    auto user = login();

    while (true) {
      user->showMenu();

      int cmd;
      std::cout << "Command: ";
      std::cin >> cmd;

      if (cmd == 0) break;

      if (cmd == 1) {
        auto products = service.listProducts();
        std::cout << "\nProducts:\n";
        for (auto& row : products) {
          for (auto& x : row) std::cout << x << " ";
          std::cout << "\n";
        }
      } else {
        std::cout << "Not implemented yet.\n";
      }
    }

  } catch (const std::exception& e) {
    std::cerr << "DB ERROR: " << e.what() << "\n";
    return 1;
  }
  return 0;
}
