#include "StoreService.h"

StoreService::StoreService(DatabaseConnection<std::string>& db) : db_(db) {}

std::vector<std::vector<std::string>> StoreService::listProducts() {
  return db_.executeQuery(
      "SELECT product_id, name, price, stock_quantity "
      "FROM products ORDER BY product_id"
  );
}
