#pragma once
#include <string>

struct Product {
    int id{};
    std::string name;
    double price{};
    int stock{};
};
