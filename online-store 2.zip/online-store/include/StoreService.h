#pragma once
#include <string>
#include <vector>
#include "DatabaseConnection.h"

class StoreService {
public:
  explicit StoreService(DatabaseConnection<std::string>& db);

  std::vector<std::vector<std::string>> listProducts();

private:
  DatabaseConnection<std::string>& db_;
};
