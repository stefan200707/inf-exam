#pragma once
#include <pqxx/pqxx>
#include <vector>
#include <string>

class StoreService {
public:
  explicit StoreService(pqxx::connection& conn);
  std::vector<std::vector<std::string>> listProducts();

private:
  pqxx::connection& conn_;
};
