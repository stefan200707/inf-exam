#include "StoreService.h"

StoreService::StoreService(pqxx::connection& conn) : conn_(conn) {}

std::vector<std::vector<std::string>> StoreService::listProducts() {
  pqxx::work tx(conn_);
  pqxx::result r = tx.exec("SELECT product_id, name, price, stock_quantity FROM products ORDER BY product_id");
  tx.commit();

  std::vector<std::vector<std::string>> out;
  for (auto row : r) {
    std::vector<std::string> line;
    for (auto f : row) line.push_back(f.c_str());
    out.push_back(std::move(line));
  }
  return out;
}
