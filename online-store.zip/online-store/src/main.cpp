#include <iostream>
#include <pqxx/pqxx>
#include "StoreService.h"

int main() {
  try {
    pqxx::connection conn{"host=localhost port=5432 dbname=store_exam user=postgres password=stef4587"};

    StoreService service(conn);
    auto rows = service.listProducts();

    std::cout << "Products:\n";
    for (auto& r : rows) {
      for (auto& x : r) std::cout << x << " ";
      std::cout << "\n";
    }

    std::cout << "\nDB OK ✅\n";
  } catch (const std::exception& e) {
    std::cerr << "DB ERROR: " << e.what() << "\n";
    return 1;
  }
  return 0;
}
